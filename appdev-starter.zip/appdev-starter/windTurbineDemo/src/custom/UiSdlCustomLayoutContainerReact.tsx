import * as React from 'react';
import UiSdlLayoutContainer from '@c3/ui/UiSdlLayoutContainerReact';
import '@c3/ui/UiSdlCustomLayoutContainer.scss';

/**
 * Renders a Custom UiSdlCardList with React.
 * @param props A UiSdlCardList configuration
 */
export default function CustomLayoutContainer(props) {
  return (
    <div className='custom-layout-container'>
      <UiSdlLayoutContainer {...props} />
    </div>
  ) 
}
