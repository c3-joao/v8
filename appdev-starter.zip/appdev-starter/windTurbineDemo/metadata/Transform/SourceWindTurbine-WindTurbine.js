data = {
    name: "SourceWindTurbine-WindTurbine",
    source: "SourceWindTurbine",
    target: "WindTurbine",
    projection: {
        id: id,
        name: name,
        turbineId: turbineId,
        location: location,
        power: power,
        manufacturer: manufacturer,
        country: country,
        city: city,
        latitude: latitude,
        longitude: longitude
    }
}
