data = {
    name: "SourceWindTurbineMeasurement-WindTurbineMeasurement",
    source: "SourceWindTurbineMeasurement",
    target: "WindTurbineMeasurement",
    projection: {
        turbineId: {id: turbineId},
        gearOilTemperature: gearOilTemperature,
        generatorRotationSpeed: generatorRotationSpeed,
        timestamp: timestamp,
        activePower: activePower
    }
}
