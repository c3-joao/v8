# Application development: v8 workshop

| Branch  | Description |
|:--------|:------------|
| main    | End-state of the application, with solved exercises |
| starter | Starting state of the application |
