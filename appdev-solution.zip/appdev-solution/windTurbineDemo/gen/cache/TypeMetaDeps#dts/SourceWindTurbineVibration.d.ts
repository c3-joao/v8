// TypeScript definitions for the C3 type SourceWindTurbineVibration

/**
 * @remarks this represents a value passed to a method that expects an instance of SourceWindTurbineVibration
 */
declare class ISourceWindTurbineVibration {

  /**
   * Indicates the source system from which this canonical is imported
   */
  sourceSystem?: string;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  timestamp?: DateTime | Date | string;

  /**
   * Id of the {@link Sources} for the Source
   */
  sourcesId?: string;

  /**
   * Encoded path of {@link SourceFile}
   */
  sourceFileEncodedPath?: string;

  /**
   * Url of the {@link SourceFile}
   */
  sourceFileUrl?: string;

  measurement_date?: DateTime | Date | string;

  energyNear1xRpm?: number;

  energyNear2xRpm?: number;

  turbineId?: string;
}

/**
 * @remarks this represents a made instance of SourceWindTurbineVibration
 */
declare class SourceWindTurbineVibration {

  /**
   * Indicates the source system from which this canonical is imported
   */
  readonly sourceSystem?: string;
  withSourceSystem(sourceSystem: string | null): SourceWindTurbineVibration;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  readonly timestamp?: DateTime;
  withTimestamp(timestamp: DateTime | Date | string | null): SourceWindTurbineVibration;

  /**
   * Id of the {@link Sources} for the Source
   */
  readonly sourcesId?: string;
  withSourcesId(sourcesId: string | null): SourceWindTurbineVibration;

  /**
   * Encoded path of {@link SourceFile}
   */
  readonly sourceFileEncodedPath?: string;
  withSourceFileEncodedPath(sourceFileEncodedPath: string | null): SourceWindTurbineVibration;

  /**
   * Url of the {@link SourceFile}
   */
  readonly sourceFileUrl?: string;
  withSourceFileUrl(sourceFileUrl: string | null): SourceWindTurbineVibration;

  readonly measurement_date?: DateTime;
  withMeasurement_date(measurement_date: DateTime | Date | string | null): SourceWindTurbineVibration;

  readonly energyNear1xRpm?: number;
  withEnergyNear1xRpm(energyNear1xRpm: number | null): SourceWindTurbineVibration;

  readonly energyNear2xRpm?: number;
  withEnergyNear2xRpm(energyNear2xRpm: number | null): SourceWindTurbineVibration;

  readonly turbineId?: string;
  withTurbineId(turbineId: string | null): SourceWindTurbineVibration;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): SourceWindTurbineVibration | null;

  static fromJsonString(json: string): SourceWindTurbineVibration | null;

  static fromXmlString(xml: string): SourceWindTurbineVibration | null;

  static deserialize(contentStr: string, contentType: string): SourceWindTurbineVibration | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): SourceWindTurbineVibration;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbineVibration;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbineVibration;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbineVibration>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbineVibration>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): SourceWindTurbineVibration;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbineVibration;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbineVibration;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): SourceWindTurbineVibration;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): SourceWindTurbineVibration;

  withField(field: FieldType, value: any, doNotConvert?: boolean): SourceWindTurbineVibration;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): SourceWindTurbineVibration;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): SourceWindTurbineVibration;

  withoutField(field: string): SourceWindTurbineVibration;

  withoutField(field: FieldType): SourceWindTurbineVibration;

  withoutFields(fields: Array_Type<string>): SourceWindTurbineVibration;

  withoutFieldsByType(fields: Array_Type<FieldType>): SourceWindTurbineVibration;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): SourceWindTurbineVibration;

  mergeObj(other: Obj): SourceWindTurbineVibration;

  mergeObj(other: Obj, otherFieldsFilter: Type): SourceWindTurbineVibration;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): SourceWindTurbineVibration;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): SourceWindTurbineVibration;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): SourceWindTurbineVibration;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): SourceWindTurbineVibration;

  sumObj(other: Obj, deep?: boolean): SourceWindTurbineVibration;

  singletonArray(): Array_Type<SourceWindTurbineVibration>;

  static array(...elements: Array_Type<any>[]): Array_Type<SourceWindTurbineVibration> | null;

  static arrayBuilder(): ArrayBuilder<SourceWindTurbineVibration> | null;

  singletonSet(): Set_Type<SourceWindTurbineVibration>;

  static setBuilder(): SetBuilder<SourceWindTurbineVibration> | null;

  static mapBuilder(): MapBuilder<string, SourceWindTurbineVibration> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, SourceWindTurbineVibration> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<SourceWindTurbineVibration>;

  static builder(): ObjBuilder<SourceWindTurbineVibration>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): SourceWindTurbineVibration;

  static make(withDefaults?: boolean): SourceWindTurbineVibration;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): SourceWindTurbineVibration;

  static make(fields: any, withDefaults?: boolean): SourceWindTurbineVibration;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): SourceWindTurbineVibration;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): SourceWindTurbineVibration;

  static cachedEmptyInst(): SourceWindTurbineVibration;

  toData(): Data | null;

  static csvHeader(): string | null;

  static allSources(): Array_Type<Type> | null;

  static allSourcesForTarget(targetType: Type): Array_Type<Type> | null;

  static allSourcesWithTargets(): Map_Type<string, Array_Type<Type>> | null;

  static allTransforms(): Stream<Transform> | null;

  static allTargetTypes(): Array_Type<Type> | null;

  static transformTargetType(transformType: Type, failIfInvalid?: boolean): Type | null;

  process(): SourceImportDataResult | null;

  static processBatch(sources: Array_Type<SourceWindTurbineVibration>): SourceImportDataResult | null;

  static processStream(sources: Stream<SourceWindTurbineVibration>): SourceImportDataResult | null;

  static importData(spec?: SourceImportDataSpec): SourceImportDataResult | null;

  static transformSource(objs: Array_Type<SourceWindTurbineVibration>, spec?: SourceTransformSpec): SourceTransformResult | null;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
