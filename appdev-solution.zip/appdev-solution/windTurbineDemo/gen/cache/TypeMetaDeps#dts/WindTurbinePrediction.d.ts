// TypeScript definitions for the C3 type WindTurbinePrediction

/**
 * @remarks this represents a value passed to a method that expects an instance of WindTurbinePrediction
 */
declare class IWindTurbinePrediction {

  /**
   * Unique id that can either be manually specified or automatically generated during object creation.  Can't be
   * changed once instance is persisted.
   */
  id: string;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  versionEdits?: Array_Type<VersionEdit> | Array<IVersionEdit>;

  /**
   * Name of the Obj instance
   */
  name?: string;

  /**
   * Various system fields.
   */
  meta?: IMeta;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  version?: number;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  typeWithBindings?: IType;

  subject: IWindTurbine;

  model: IMlModel;

  timestamp: DateTime | Date | string;

  status: string;

  value: number;
}

/**
 * @remarks this represents a made instance of WindTurbinePrediction
 */
declare class WindTurbinePrediction {

  /**
   * Unique id that can either be manually specified or automatically generated during object creation.  Can't be
   * changed once instance is persisted.
   */
  readonly id: string;
  withId(id: string): WindTurbinePrediction;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  readonly versionEdits?: Array_Type<VersionEdit>;
  withVersionEdits(versionEdits: Array_Type<VersionEdit> | Array<IVersionEdit> | null): WindTurbinePrediction;

  /**
   * Name of the Obj instance
   */
  readonly name?: string;
  withName(name: string | null): WindTurbinePrediction;

  /**
   * Various system fields.
   */
  readonly meta?: Meta;
  withMeta(meta: IMeta | null): WindTurbinePrediction;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  readonly version?: number;
  withVersion(version: number | null): WindTurbinePrediction;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  readonly typeWithBindings?: Type;
  withTypeWithBindings(typeWithBindings: IType | null): WindTurbinePrediction;

  readonly subject: WindTurbine;
  withSubject(subject: IWindTurbine): WindTurbinePrediction;

  readonly model: MlModel;
  withModel(model: IMlModel): WindTurbinePrediction;

  readonly timestamp: DateTime;
  withTimestamp(timestamp: DateTime | Date | string): WindTurbinePrediction;

  readonly status: string;
  withStatus(status: string): WindTurbinePrediction;

  readonly value: number;
  withValue(value: number): WindTurbinePrediction;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): WindTurbinePrediction | null;

  static fromJsonString(json: string): WindTurbinePrediction | null;

  static fromXmlString(xml: string): WindTurbinePrediction | null;

  static deserialize(contentStr: string, contentType: string): WindTurbinePrediction | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): WindTurbinePrediction;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbinePrediction;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbinePrediction;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbinePrediction>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbinePrediction>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): WindTurbinePrediction;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbinePrediction;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbinePrediction;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): WindTurbinePrediction;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): WindTurbinePrediction;

  withField(field: FieldType, value: any, doNotConvert?: boolean): WindTurbinePrediction;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): WindTurbinePrediction;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): WindTurbinePrediction;

  withoutField(field: string): WindTurbinePrediction;

  withoutField(field: FieldType): WindTurbinePrediction;

  withoutFields(fields: Array_Type<string>): WindTurbinePrediction;

  withoutFieldsByType(fields: Array_Type<FieldType>): WindTurbinePrediction;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): WindTurbinePrediction;

  mergeObj(other: Obj): WindTurbinePrediction;

  mergeObj(other: Obj, otherFieldsFilter: Type): WindTurbinePrediction;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): WindTurbinePrediction;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): WindTurbinePrediction;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): WindTurbinePrediction;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): WindTurbinePrediction;

  sumObj(other: Obj, deep?: boolean): WindTurbinePrediction;

  singletonArray(): Array_Type<WindTurbinePrediction>;

  static array(...elements: Array_Type<any>[]): Array_Type<WindTurbinePrediction> | null;

  static arrayBuilder(): ArrayBuilder<WindTurbinePrediction> | null;

  singletonSet(): Set_Type<WindTurbinePrediction>;

  static setBuilder(): SetBuilder<WindTurbinePrediction> | null;

  static mapBuilder(): MapBuilder<string, WindTurbinePrediction> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, WindTurbinePrediction> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<WindTurbinePrediction>;

  static builder(): ObjBuilder<WindTurbinePrediction>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): WindTurbinePrediction;

  static make(withDefaults?: boolean): WindTurbinePrediction;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): WindTurbinePrediction;

  static make(fields: any, withDefaults?: boolean): WindTurbinePrediction;

  static make(s: string): WindTurbinePrediction | null;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): WindTurbinePrediction;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): WindTurbinePrediction;

  static cachedEmptyInst(): WindTurbinePrediction;

  toData(): Data | null;

  static fetch(spec?: FetchSpec): FetchResult<WindTurbinePrediction>;

  static fetch(filter: Filter): FetchResult<WindTurbinePrediction>;

  static fetchObjStream(spec?: FetchStreamSpec): Stream<WindTurbinePrediction> | null;

  static fetchMultiLocale(spec?: MultiLocaleFetchSpec): Map_Type<string, FetchResult<WindTurbinePrediction>> | null;

  static fetchCount(spec?: FetchFilterSpec): number;

  static fetchCountEstimated(spec?: FetchFilterSpec, updateStatistics?: boolean): number;

  static scan(spec: ScanSpec): ScanStats | null;

  static batchIds(spec?: BatchIdsSpec): Stream<string> | null;

  static exists(spec?: ExistsSpec): boolean;

  static exists(filter: Filter): boolean;

  static fetchOvi(spec?: FetchSpec): any | null;

  get(include?: string): WindTurbinePrediction | null;

  getSpecific(include?: string): WindTurbinePrediction | null;

  getMissing(spec: GetMissingSpec): WindTurbinePrediction;

  getDirect(): WindTurbinePrediction | null;

  applyReverseEdit(versionEdit: VersionEdit): WindTurbinePrediction;

  static keyFieldType(): FieldType;

  keyFieldValue(): string | null;

  singletonMap(): Map_Type<string, WithKey>;

  toString(): string | null;

  static fromString(s: string): WindTurbinePrediction | null;

  create(spec?: UpsertSpec): WindTurbinePrediction | null;

  static createBatch(objs: Array_Type<WindTurbinePrediction>, spec?: UpsertSpec): ObjList<WindTurbinePrediction> | null;

  static createBatchObjStream(objs: Stream<WindTurbinePrediction>, spec?: CreateBatchObjStreamSpec): ObjList<WindTurbinePrediction> | null;

  update(srcObj?: WindTurbinePrediction, spec?: UpsertSpec): WindTurbinePrediction | null;

  upsert(srcObj?: WindTurbinePrediction, spec?: UpsertSpec): WindTurbinePrediction | null;

  merge(spec?: MergeSpec): WindTurbinePrediction | null;

  touch(spec?: TouchSpec): WindTurbinePrediction | null;

  static updateBatch(objs: Array_Type<WindTurbinePrediction>, srcObjs?: Array_Type<WindTurbinePrediction>, spec?: UpsertSpec): ObjList<WindTurbinePrediction> | null;

  static upsertBatch(objs: Array_Type<WindTurbinePrediction>, srcObjs?: Array_Type<WindTurbinePrediction>, spec?: UpsertSpec): ObjList<WindTurbinePrediction> | null;

  static touchBatch(objs: Array_Type<WindTurbinePrediction>, spec?: TouchSpec): ObjList<WindTurbinePrediction> | null;

  static mergeBatch(objs: Array_Type<WindTurbinePrediction>, spec?: MergeSpec): ObjList<WindTurbinePrediction> | null;

  static mergeAll(mergeObj: WindTurbinePrediction, spec?: MergeAllSpec): number | null;

  remove(spec?: UpsertSpec): boolean;

  static removeBatch(objs: Array_Type<WindTurbinePrediction>, spec?: UpsertSpec): ObjList<WindTurbinePrediction> | null;

  static removeAll(spec?: RemoveAllSpec, confirm: boolean): number;

  static replace(objs: Array_Type<WindTurbinePrediction>, spec?: UpsertSpec): ObjList<WindTurbinePrediction> | null;

  unremove(): WindTurbinePrediction | null;

  static beforeCreate(objs: Array_Type<WindTurbinePrediction>): ObjList<WindTurbinePrediction>;

  static beforeUpdate(objs: Array_Type<WindTurbinePrediction>): ObjList<WindTurbinePrediction>;

  static beforeRemove(objs: Array_Type<WindTurbinePrediction>): ObjList<WindTurbinePrediction>;

  static afterCreate(objs: Array_Type<WindTurbinePrediction>): Array_Type<ObjError> | null;

  static afterUpdate(objs: Array_Type<WindTurbinePrediction>): Array_Type<ObjError> | null;

  static afterRemove(objs: Array_Type<WindTurbinePrediction>): Array_Type<ObjError> | null;

  upsertDirect(merge?: boolean, clearNullValues?: boolean): Obj | null;

  static beginUpsertToSecondaryDs(type: Type): SecondaryDsUpsert;

  static clearCollection(spec?: ClearCollectionSpec, confirm: boolean): void;

  static created(txn: Transaction): void;

  static updated(txn: Transaction): void;

  static removed(txn: Transaction): void;

  static eval(spec?: EvalSpec): Data | null;

  static evaluate(spec: EvaluateSpec): EvaluateResult | null;

  static evaluateTupleStream(spec: EvaluateSpec): Stream<CellTuple> | null;

  static evaluatePii(spec: EvaluateSpec): EvaluateResult | null;

  static tsEval(spec: TSEvalSpec): Obj | null;

  static evaluateOvi(spec?: EvaluateSpec): any | null;

  static refreshCalcFields(spec?: RefreshCalcFieldsSpec): RefreshCalcFieldsBatchJob | null;

  static refreshDefaultFields(spec?: RefreshDefaultFieldsSpec): RefreshDefaultFieldsBatchJob | null;

  static refreshUniqueIndexes(spec?: RefreshUniqueIndexesSpec): RefreshUniqueIndexesBatchJob | null;

  static refreshAnalytics(spec?: RefreshAnalyticsSpec): RefreshAnalyticsBatchJob | null;

  static refreshMetrics(spec?: RefreshMetricsSpec): RefreshMetricsBatchJob | null;

  static runCreatedOrUpdated(spec?: RunCreatedOrUpdatedSpec): RunCreatedOrUpdatedBatchJob | null;

  static refreshDeps(spec?: RefreshDepsSpec): void;

  static processRefresh(type: Type, jobType: Type, spec: ObjBatch): RefreshBatchJob<any, any, any> | null;

  static startImportData(spec?: StartImportDataSpec): PushStream<WindTurbinePrediction>;

  static startImportDataWithStats(spec?: StartImportDataSpec): PushStreamWithStats<WindTurbinePrediction>;

  static importData(spec: ImportDataSpec, async?: boolean): ImportDataResult | null;

  static exportData(spec: ExportDataSpec): ExportDataResult | null;

  static exportDataForRedShift(spec: RedShiftExportDataSpec): number | null;

  static forId(id: string, failIfMissing?: boolean): WindTurbinePrediction | null;

  referenceInvalid(): boolean;

  static generateNewIds(count?: number): Array_Type<string> | null;

  static generateData(spec?: GenerateDataSpec): ActionStats | null;

  static profileData(spec?: FetchSpec): GenerateDataSpec | null;

  withoutIdentity(): WindTurbinePrediction | null;

  typeOf(): EntityType | null;

  static typeOfBatch(objs: Array_Type<WindTurbinePrediction>): Array_Type<EntityType> | null;

  static getRootType(): Type | null;

  static upsertCollection(old?: Type): boolean;

  static collectionUpserted(): void;

  static collectionCleared(): void;

  static dbEcho(template?: WindTurbinePrediction, count?: number, sendBack?: boolean): number | null;

  static checkReferences(spec?: CheckReferencesSpec): CheckReferencesResult | null;

  static validatePath(path: string): ValidatePathResult | null;

  static schema(): SchemaInfo | null;

  static calcFieldDeps(fieldName: string): Array_Type<string> | null;

  invalidateTsHeader(range?: TimeRange, fields?: Array_Type<string>, autoCommit?: boolean): void;

  static invalidateTsDataPoints(tsInvalidations: Stream<TsInvalidation>, autoCommit?: boolean): void;

  static eachObjBatch(spec: BatchFetchSpec, action: λBiConsumer<Array_Type<Obj>, any | null>): string;

  static callbackLogic(objs: Array_Type<WindTurbinePrediction>, callback?: λFunction<WindTurbinePrediction | null, WindTurbinePrediction | null>): ObjList<WindTurbinePrediction>;

  static afterCallbackLogic(objs: Array_Type<WindTurbinePrediction>, callback?: λFunction<WindTurbinePrediction | null, WindTurbinePrediction | null>): Array_Type<ObjError> | null;

  static isSystemField(name: string): boolean;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
