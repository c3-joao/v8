// TypeScript definitions for the C3 type SourceWindTurbineEvent

/**
 * @remarks this represents a value passed to a method that expects an instance of SourceWindTurbineEvent
 */
declare class ISourceWindTurbineEvent {

  /**
   * Indicates the source system from which this canonical is imported
   */
  sourceSystem?: string;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  timestamp?: DateTime | Date | string;

  /**
   * Id of the {@link Sources} for the Source
   */
  sourcesId?: string;

  /**
   * Encoded path of {@link SourceFile}
   */
  sourceFileEncodedPath?: string;

  /**
   * Url of the {@link SourceFile}
   */
  sourceFileUrl?: string;

  start?: DateTime | Date | string;

  end?: DateTime | Date | string;

  event_code?: string;

  turbineId?: string;
}

/**
 * @remarks this represents a made instance of SourceWindTurbineEvent
 */
declare class SourceWindTurbineEvent {

  /**
   * Indicates the source system from which this canonical is imported
   */
  readonly sourceSystem?: string;
  withSourceSystem(sourceSystem: string | null): SourceWindTurbineEvent;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  readonly timestamp?: DateTime;
  withTimestamp(timestamp: DateTime | Date | string | null): SourceWindTurbineEvent;

  /**
   * Id of the {@link Sources} for the Source
   */
  readonly sourcesId?: string;
  withSourcesId(sourcesId: string | null): SourceWindTurbineEvent;

  /**
   * Encoded path of {@link SourceFile}
   */
  readonly sourceFileEncodedPath?: string;
  withSourceFileEncodedPath(sourceFileEncodedPath: string | null): SourceWindTurbineEvent;

  /**
   * Url of the {@link SourceFile}
   */
  readonly sourceFileUrl?: string;
  withSourceFileUrl(sourceFileUrl: string | null): SourceWindTurbineEvent;

  readonly start?: DateTime;
  withStart(start: DateTime | Date | string | null): SourceWindTurbineEvent;

  readonly end?: DateTime;
  withEnd(end: DateTime | Date | string | null): SourceWindTurbineEvent;

  readonly event_code?: string;
  withEvent_code(event_code: string | null): SourceWindTurbineEvent;

  readonly turbineId?: string;
  withTurbineId(turbineId: string | null): SourceWindTurbineEvent;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): SourceWindTurbineEvent | null;

  static fromJsonString(json: string): SourceWindTurbineEvent | null;

  static fromXmlString(xml: string): SourceWindTurbineEvent | null;

  static deserialize(contentStr: string, contentType: string): SourceWindTurbineEvent | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): SourceWindTurbineEvent;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbineEvent;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbineEvent;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbineEvent>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbineEvent>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): SourceWindTurbineEvent;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbineEvent;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbineEvent;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): SourceWindTurbineEvent;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): SourceWindTurbineEvent;

  withField(field: FieldType, value: any, doNotConvert?: boolean): SourceWindTurbineEvent;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): SourceWindTurbineEvent;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): SourceWindTurbineEvent;

  withoutField(field: string): SourceWindTurbineEvent;

  withoutField(field: FieldType): SourceWindTurbineEvent;

  withoutFields(fields: Array_Type<string>): SourceWindTurbineEvent;

  withoutFieldsByType(fields: Array_Type<FieldType>): SourceWindTurbineEvent;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): SourceWindTurbineEvent;

  mergeObj(other: Obj): SourceWindTurbineEvent;

  mergeObj(other: Obj, otherFieldsFilter: Type): SourceWindTurbineEvent;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): SourceWindTurbineEvent;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): SourceWindTurbineEvent;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): SourceWindTurbineEvent;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): SourceWindTurbineEvent;

  sumObj(other: Obj, deep?: boolean): SourceWindTurbineEvent;

  singletonArray(): Array_Type<SourceWindTurbineEvent>;

  static array(...elements: Array_Type<any>[]): Array_Type<SourceWindTurbineEvent> | null;

  static arrayBuilder(): ArrayBuilder<SourceWindTurbineEvent> | null;

  singletonSet(): Set_Type<SourceWindTurbineEvent>;

  static setBuilder(): SetBuilder<SourceWindTurbineEvent> | null;

  static mapBuilder(): MapBuilder<string, SourceWindTurbineEvent> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, SourceWindTurbineEvent> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<SourceWindTurbineEvent>;

  static builder(): ObjBuilder<SourceWindTurbineEvent>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): SourceWindTurbineEvent;

  static make(withDefaults?: boolean): SourceWindTurbineEvent;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): SourceWindTurbineEvent;

  static make(fields: any, withDefaults?: boolean): SourceWindTurbineEvent;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): SourceWindTurbineEvent;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): SourceWindTurbineEvent;

  static cachedEmptyInst(): SourceWindTurbineEvent;

  toData(): Data | null;

  static csvHeader(): string | null;

  static allSources(): Array_Type<Type> | null;

  static allSourcesForTarget(targetType: Type): Array_Type<Type> | null;

  static allSourcesWithTargets(): Map_Type<string, Array_Type<Type>> | null;

  static allTransforms(): Stream<Transform> | null;

  static allTargetTypes(): Array_Type<Type> | null;

  static transformTargetType(transformType: Type, failIfInvalid?: boolean): Type | null;

  process(): SourceImportDataResult | null;

  static processBatch(sources: Array_Type<SourceWindTurbineEvent>): SourceImportDataResult | null;

  static processStream(sources: Stream<SourceWindTurbineEvent>): SourceImportDataResult | null;

  static importData(spec?: SourceImportDataSpec): SourceImportDataResult | null;

  static transformSource(objs: Array_Type<SourceWindTurbineEvent>, spec?: SourceTransformSpec): SourceTransformResult | null;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
