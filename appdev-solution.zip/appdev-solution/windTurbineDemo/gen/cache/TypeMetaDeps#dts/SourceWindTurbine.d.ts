// TypeScript definitions for the C3 type SourceWindTurbine

/**
 * @remarks this represents a value passed to a method that expects an instance of SourceWindTurbine
 */
declare class ISourceWindTurbine {

  /**
   * Indicates the source system from which this canonical is imported
   */
  sourceSystem?: string;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  timestamp?: DateTime | Date | string;

  /**
   * Id of the {@link Sources} for the Source
   */
  sourcesId?: string;

  /**
   * Encoded path of {@link SourceFile}
   */
  sourceFileEncodedPath?: string;

  /**
   * Url of the {@link SourceFile}
   */
  sourceFileUrl?: string;

  id?: string;

  name?: string;

  turbineId?: string;

  manufacturer?: string;

  power?: number;

  location?: string;

  country?: string;

  city?: string;

  latitude?: number;

  longitude?: number;
}

/**
 * @remarks this represents a made instance of SourceWindTurbine
 */
declare class SourceWindTurbine {

  /**
   * Indicates the source system from which this canonical is imported
   */
  readonly sourceSystem?: string;
  withSourceSystem(sourceSystem: string | null): SourceWindTurbine;

  /**
   * Indicates the timestamp of the canonical in source system
   */
  readonly timestamp?: DateTime;
  withTimestamp(timestamp: DateTime | Date | string | null): SourceWindTurbine;

  /**
   * Id of the {@link Sources} for the Source
   */
  readonly sourcesId?: string;
  withSourcesId(sourcesId: string | null): SourceWindTurbine;

  /**
   * Encoded path of {@link SourceFile}
   */
  readonly sourceFileEncodedPath?: string;
  withSourceFileEncodedPath(sourceFileEncodedPath: string | null): SourceWindTurbine;

  /**
   * Url of the {@link SourceFile}
   */
  readonly sourceFileUrl?: string;
  withSourceFileUrl(sourceFileUrl: string | null): SourceWindTurbine;

  readonly id?: string;
  withId(id: string | null): SourceWindTurbine;

  readonly name?: string;
  withName(name: string | null): SourceWindTurbine;

  readonly turbineId?: string;
  withTurbineId(turbineId: string | null): SourceWindTurbine;

  readonly manufacturer?: string;
  withManufacturer(manufacturer: string | null): SourceWindTurbine;

  readonly power?: number;
  withPower(power: number | null): SourceWindTurbine;

  readonly location?: string;
  withLocation(location: string | null): SourceWindTurbine;

  readonly country?: string;
  withCountry(country: string | null): SourceWindTurbine;

  readonly city?: string;
  withCity(city: string | null): SourceWindTurbine;

  readonly latitude?: number;
  withLatitude(latitude: number | null): SourceWindTurbine;

  readonly longitude?: number;
  withLongitude(longitude: number | null): SourceWindTurbine;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): SourceWindTurbine | null;

  static fromJsonString(json: string): SourceWindTurbine | null;

  static fromXmlString(xml: string): SourceWindTurbine | null;

  static deserialize(contentStr: string, contentType: string): SourceWindTurbine | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): SourceWindTurbine;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbine;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): SourceWindTurbine;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbine>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<SourceWindTurbine>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): SourceWindTurbine;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbine;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): SourceWindTurbine;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): SourceWindTurbine;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): SourceWindTurbine;

  withField(field: FieldType, value: any, doNotConvert?: boolean): SourceWindTurbine;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): SourceWindTurbine;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): SourceWindTurbine;

  withoutField(field: string): SourceWindTurbine;

  withoutField(field: FieldType): SourceWindTurbine;

  withoutFields(fields: Array_Type<string>): SourceWindTurbine;

  withoutFieldsByType(fields: Array_Type<FieldType>): SourceWindTurbine;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): SourceWindTurbine;

  mergeObj(other: Obj): SourceWindTurbine;

  mergeObj(other: Obj, otherFieldsFilter: Type): SourceWindTurbine;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): SourceWindTurbine;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): SourceWindTurbine;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): SourceWindTurbine;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): SourceWindTurbine;

  sumObj(other: Obj, deep?: boolean): SourceWindTurbine;

  singletonArray(): Array_Type<SourceWindTurbine>;

  static array(...elements: Array_Type<any>[]): Array_Type<SourceWindTurbine> | null;

  static arrayBuilder(): ArrayBuilder<SourceWindTurbine> | null;

  singletonSet(): Set_Type<SourceWindTurbine>;

  static setBuilder(): SetBuilder<SourceWindTurbine> | null;

  static mapBuilder(): MapBuilder<string, SourceWindTurbine> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, SourceWindTurbine> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<SourceWindTurbine>;

  static builder(): ObjBuilder<SourceWindTurbine>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): SourceWindTurbine;

  static make(withDefaults?: boolean): SourceWindTurbine;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): SourceWindTurbine;

  static make(fields: any, withDefaults?: boolean): SourceWindTurbine;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): SourceWindTurbine;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): SourceWindTurbine;

  static cachedEmptyInst(): SourceWindTurbine;

  toData(): Data | null;

  static csvHeader(): string | null;

  static allSources(): Array_Type<Type> | null;

  static allSourcesForTarget(targetType: Type): Array_Type<Type> | null;

  static allSourcesWithTargets(): Map_Type<string, Array_Type<Type>> | null;

  static allTransforms(): Stream<Transform> | null;

  static allTargetTypes(): Array_Type<Type> | null;

  static transformTargetType(transformType: Type, failIfInvalid?: boolean): Type | null;

  process(): SourceImportDataResult | null;

  static processBatch(sources: Array_Type<SourceWindTurbine>): SourceImportDataResult | null;

  static processStream(sources: Stream<SourceWindTurbine>): SourceImportDataResult | null;

  static importData(spec?: SourceImportDataSpec): SourceImportDataResult | null;

  static transformSource(objs: Array_Type<SourceWindTurbine>, spec?: SourceTransformSpec): SourceTransformResult | null;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
