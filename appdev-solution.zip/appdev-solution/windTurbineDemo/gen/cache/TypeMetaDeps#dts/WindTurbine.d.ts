// TypeScript definitions for the C3 type WindTurbine

/**
 * @remarks this represents a value passed to a method that expects an instance of WindTurbine
 */
declare class IWindTurbine {

  /**
   * The id of this instance.
   */
  id?: string;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  versionEdits?: Array_Type<VersionEdit> | Array<IVersionEdit>;

  /**
   * Name of the Obj instance
   */
  name?: string;

  /**
   * Various system fields.
   */
  meta?: IMeta;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  version?: number;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  typeWithBindings?: IType;

  /**
   * The id of the wind turbine.
   */
  turbineId?: string;

  /**
   * The country of the wind turbine.
   */
  country?: string;

  /**
   * The city of the wind turbine.
   */
  city?: string;

  /**
   * The latitude of the wind turbine.
   */
  latitude?: number;

  /**
   * The longitude of the wind turbine.
   */
  longitude?: number;

  /**
   * Nominal power of the wind turbine (e.g., 150 mega watts).
   */
  power?: number;

  /**
   * The manufacturer of the wind turbine.
   */
  manufacturer?: string;

  /**
   * The {@link WindTurbineMeasurement} belonging to the wind turbine.
   */
  measurements?: Array_Type<WindTurbineMeasurement> | Array<IWindTurbineMeasurement>;

  /**
   * The {@link WindTurbineEvent}s belonging to the wind turbine.
   */
  events?: Array_Type<WindTurbineEvent> | Array<IWindTurbineEvent>;

  /**
   * Returns the number of unplanned maintenance events for this wind turbine
   */
  unplannedMaintenanceEvents?: number;

  /**
   * Returns the number of planned maintenance events for this wind turbine
   */
  plannedMaintenanceEvents?: number;

  /**
   * Returns the number of forced shutdown / reboots for a wind turbine
   */
  rebootEvents?: number;

  /**
   * Returns the latest event for this wind turbine
   */
  latestEvent?: string;
}

/**
 * @remarks this represents a made instance of WindTurbine
 */
declare class WindTurbine {

  /**
   * The id of this instance.
   */
  readonly id?: string;
  withId(id: string | null): WindTurbine;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  readonly versionEdits?: Array_Type<VersionEdit>;
  withVersionEdits(versionEdits: Array_Type<VersionEdit> | Array<IVersionEdit> | null): WindTurbine;

  /**
   * Name of the Obj instance
   */
  readonly name?: string;
  withName(name: string | null): WindTurbine;

  /**
   * Various system fields.
   */
  readonly meta?: Meta;
  withMeta(meta: IMeta | null): WindTurbine;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  readonly version?: number;
  withVersion(version: number | null): WindTurbine;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  readonly typeWithBindings?: Type;
  withTypeWithBindings(typeWithBindings: IType | null): WindTurbine;

  /**
   * The id of the wind turbine.
   */
  readonly turbineId?: string;
  withTurbineId(turbineId: string | null): WindTurbine;

  /**
   * The country of the wind turbine.
   */
  readonly country?: string;
  withCountry(country: string | null): WindTurbine;

  /**
   * The city of the wind turbine.
   */
  readonly city?: string;
  withCity(city: string | null): WindTurbine;

  /**
   * The latitude of the wind turbine.
   */
  readonly latitude?: number;
  withLatitude(latitude: number | null): WindTurbine;

  /**
   * The longitude of the wind turbine.
   */
  readonly longitude?: number;
  withLongitude(longitude: number | null): WindTurbine;

  /**
   * Nominal power of the wind turbine (e.g., 150 mega watts).
   */
  readonly power?: number;
  withPower(power: number | null): WindTurbine;

  /**
   * The manufacturer of the wind turbine.
   */
  readonly manufacturer?: string;
  withManufacturer(manufacturer: string | null): WindTurbine;

  /**
   * The {@link WindTurbineMeasurement} belonging to the wind turbine.
   */
  readonly measurements?: Array_Type<WindTurbineMeasurement>;
  withMeasurements(measurements: Array_Type<WindTurbineMeasurement> | Array<IWindTurbineMeasurement> | null): WindTurbine;

  /**
   * The {@link WindTurbineEvent}s belonging to the wind turbine.
   */
  readonly events?: Array_Type<WindTurbineEvent>;
  withEvents(events: Array_Type<WindTurbineEvent> | Array<IWindTurbineEvent> | null): WindTurbine;

  /**
   * Returns the number of unplanned maintenance events for this wind turbine
   */
  readonly unplannedMaintenanceEvents?: number;
  withUnplannedMaintenanceEvents(unplannedMaintenanceEvents: number | null): WindTurbine;

  /**
   * Returns the number of planned maintenance events for this wind turbine
   */
  readonly plannedMaintenanceEvents?: number;
  withPlannedMaintenanceEvents(plannedMaintenanceEvents: number | null): WindTurbine;

  /**
   * Returns the number of forced shutdown / reboots for a wind turbine
   */
  readonly rebootEvents?: number;
  withRebootEvents(rebootEvents: number | null): WindTurbine;

  /**
   * Returns the latest event for this wind turbine
   */
  readonly latestEvent?: string;
  withLatestEvent(latestEvent: string | null): WindTurbine;

  renderer(): HtmlRenderer | null;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): WindTurbine | null;

  static fromJsonString(json: string): WindTurbine | null;

  static fromXmlString(xml: string): WindTurbine | null;

  static deserialize(contentStr: string, contentType: string): WindTurbine | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): WindTurbine;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbine;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbine;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbine>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbine>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): WindTurbine;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbine;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbine;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): WindTurbine;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): WindTurbine;

  withField(field: FieldType, value: any, doNotConvert?: boolean): WindTurbine;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): WindTurbine;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): WindTurbine;

  withoutField(field: string): WindTurbine;

  withoutField(field: FieldType): WindTurbine;

  withoutFields(fields: Array_Type<string>): WindTurbine;

  withoutFieldsByType(fields: Array_Type<FieldType>): WindTurbine;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): WindTurbine;

  mergeObj(other: Obj): WindTurbine;

  mergeObj(other: Obj, otherFieldsFilter: Type): WindTurbine;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): WindTurbine;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): WindTurbine;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): WindTurbine;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): WindTurbine;

  sumObj(other: Obj, deep?: boolean): WindTurbine;

  singletonArray(): Array_Type<WindTurbine>;

  static array(...elements: Array_Type<any>[]): Array_Type<WindTurbine> | null;

  static arrayBuilder(): ArrayBuilder<WindTurbine> | null;

  singletonSet(): Set_Type<WindTurbine>;

  static setBuilder(): SetBuilder<WindTurbine> | null;

  static mapBuilder(): MapBuilder<string, WindTurbine> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, WindTurbine> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<WindTurbine>;

  static builder(): ObjBuilder<WindTurbine>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): WindTurbine;

  static make(withDefaults?: boolean): WindTurbine;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): WindTurbine;

  static make(fields: any, withDefaults?: boolean): WindTurbine;

  static make(s: string): WindTurbine | null;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): WindTurbine;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): WindTurbine;

  static cachedEmptyInst(): WindTurbine;

  toData(): Data | null;

  static listMetrics(): Array_Type<Metric> | null;

  static listMetricsByKind(): ListMetricsResult | null;

  static getSimpleMetric(metricName: string): SimpleMetric | null;

  static evalMetric(spec?: EvalMetricSpec): Timeseries<any> | null;

  static evalMetrics(spec?: EvalMetricsSpec): EvalMetricsResult | null;

  static evalAggregateMetrics(spec?: EvalMetricsSpec): Map_Type<string, Map_Type<string, Dimension>> | null;

  static rollupMetric(spec?: RollupMetricSpec): Timeseries<any> | null;

  static rollupMetrics(spec?: RollupMetricSpec): Map_Type<string, Timeseries<any>> | null;

  static rollupMetricsWithMetadata(spec?: RollupMetricSpec, overrideMetrics?: Array_Type<Metric>): Map_Type<string, Timeseries<any>> | null;

  static metricVariables(expression: string): Array_Type<MetricVariable> | null;

  static evalMetricsWithMetadata(spec?: EvalMetricsSpec, overrideMetrics?: Array_Type<Metric>): EvalMetricsResult | null;

  static exportMetricsDataJob(spec?: EvalMetricsSpec, additionalExportSpec?: AdditionalExportSpec, numObjPerFile?: number, typeForSrcIds?: Type): Export | null;

  static importMetricsDataJob(filePrefix?: string): Import | null;

  static extractMetricsData(spec?: EvalMetricsSpec, additionalExportSpec?: AdditionalExportSpec): ExportedObj | null;

  static importMetricsData(input?: ExportedObj): void;

  static refreshMetricsCache(ids?: Array_Type<string>, metricNames?: Array_Type<string>, startDate?: DateTime, endDate?: DateTime): void;

  static startMetricsCacheRefreshJob(metricNames?: Array_Type<string>, batchSize?: number, filter?: string, startDate?: DateTime, endDate?: DateTime): MetricsCacheRefreshJob | null;

  static metricsCacheRefreshJobStatus(): MapReduceStatus | null;

  static generateMetricsStats(ids?: Array_Type<string>, metricNames?: Array_Type<string>, startDate?: DateTime, endDate?: DateTime, interval?: string, testHash?: boolean): void;

  static startMetricsStatsJob(metricNames?: Array_Type<string>, batchSize?: number, filter?: string, startDate?: DateTime, endDate?: DateTime, interval?: string, testHash?: boolean): MetricsStatsJob | null;

  static metricsStatsJobStatus(): MapReduceStatus | null;

  static getDistribution(ids: Array_Type<string>, metricName: string, period?: string, start?: DateTime, end?: DateTime, ignoreZeroValues?: boolean, binningType?: string, numberBins?: number): HistogramEvaluationResult | null;

  static evalMetricsStats(spec: EvalMetricsSpec): Map_Type<string, Map_Type<string, TimeseriesStats>> | null;

  static startEvalMetricsBatch(spec: EvalMetricsSpec): string | null;

  static endEvalMetricsBatch(key: string): number | null;

  static evalMetricsBatch(key: string, start: DateTime, end: DateTime): EvalMetricsResult | null;

  static evalMetricsBatchKey(spec: EvalMetricsSpec): string | null;

  static isSubset(parent: EvalMetricsSpec, child: EvalMetricsSpec): boolean;

  static estimateEvalMetricsBatchCacheSize(key: string): EvalMetricsBatchCacheSize | null;

  static listEvalMetricsBatchKeys(): Array_Type<string> | null;

  static getExportEvalPlan(spec?: EvalMetricsSpec): EvalPlan | null;

  static generateEvalMetricsSpec(spec: EvalMetricsSpec, overrideMetrics?: Array_Type<Metric>): Pair<EvalMetricsSpec, Array_Type<Metric>>;

  static fetch(spec?: FetchSpec): FetchResult<WindTurbine>;

  static fetch(filter: Filter): FetchResult<WindTurbine>;

  static fetchObjStream(spec?: FetchStreamSpec): Stream<WindTurbine> | null;

  static fetchMultiLocale(spec?: MultiLocaleFetchSpec): Map_Type<string, FetchResult<WindTurbine>> | null;

  static fetchCount(spec?: FetchFilterSpec): number;

  static fetchCountEstimated(spec?: FetchFilterSpec, updateStatistics?: boolean): number;

  static scan(spec: ScanSpec): ScanStats | null;

  static batchIds(spec?: BatchIdsSpec): Stream<string> | null;

  static exists(spec?: ExistsSpec): boolean;

  static exists(filter: Filter): boolean;

  static eval(spec?: EvalSpec): Data | null;

  static evaluate(spec: EvaluateSpec): EvaluateResult | null;

  static evaluateTupleStream(spec: EvaluateSpec): Stream<CellTuple> | null;

  static evaluatePii(spec: EvaluateSpec): EvaluateResult | null;

  static tsEval(spec: TSEvalSpec): Obj | null;

  static features(): Stream<Feature> | null;

  evalFeature(feature: string, spec?: EvalFeatureSpec): Data | null;

  evalFeatureSet(featureSet: Feature.Set, spec?: EvalFeatureSpec): Data | null;

  static evalFeatureSetBatch(batch: Array_Type<WindTurbine>, featureSet: Feature.Set, spec?: EvalFeatureSpec): Data | null;

  static evalFeatureSetBatch(filter: string, featureSet: Feature.Set, spec?: EvalFeatureSpec): Data | null;

  evalFeatures(features: Array_Type<string>, spec?: EvalFeaturesSpec): Data | null;

  static evalFeaturesBatch(batch: Array_Type<WindTurbine>, features: Array_Type<string>, spec?: EvalFeaturesSpec): Data | null;

  static evalFeaturesBatch(filter: string, features: Array_Type<string>, spec?: EvalFeaturesSpec): Data | null;

  dataFromDates(dates?: Array_Type<DateTime>): Data | null;

  dataFromTimeRanges(timeRanges?: Array_Type<TimeRange>): Data | null;

  static keyFieldType(): FieldType;

  keyFieldValue(): string | null;

  singletonMap(): Map_Type<string, WithKey>;

  toString(): string | null;

  static fromString(s: string): WindTurbine | null;

  routes(project: MlProject, statusFilter?: string): Array_Type<MlModel.Route> | null;

  models(project: MlProject, statusFilter?: string): Array_Type<MlModel> | null;

  static modelsPerSubject(subjects: Array_Type<MlSubject>, project: MlProject, statusFilter?: string): Map_Type<string, Array_Type<MlModel>> | null;

  static modelsPerSubject(subjectFilter: string, project: MlProject, statusFilter?: string): Map_Type<string, Array_Type<MlModel>> | null;

  static routesSubjectsPerModel(subjects: Array_Type<MlSubject>, spec: MlSubject.OperationSpec): Map_Type<string, Map_Type<string, Array_Type<MlSubject>>>;

  static projects(): Array_Type<MlProject> | null;

  process(spec: MlSubject.OperationSpec): MlSubject.ProcessResult;

  processWithChampion(spec: MlSubject.OperationSpec): MlSubject.ProcessResult;

  static processBatch(subjects?: Array_Type<MlSubject>, spec: MlSubject.OperationSpec): MlSubject.ProcessResult;

  static startProcessJob(spec: MlSubject.OperationJobSpec): MlSubject.ProcessJob;

  interpret(spec: MlSubject.OperationSpec): MlSubject.InterpretResult;

  interpretWithChampion(spec: MlSubject.OperationSpec): MlSubject.InterpretResult;

  static interpretBatch(subjects?: Array_Type<MlSubject>, spec: MlSubject.OperationSpec): MlSubject.InterpretResult;

  static startInterpretJob(spec: MlSubject.OperationJobSpec): MlSubject.InterpretJob;

  static fetchOvi(spec?: FetchSpec): any | null;

  get(include?: string): WindTurbine | null;

  getSpecific(include?: string): WindTurbine | null;

  getMissing(spec: GetMissingSpec): WindTurbine;

  getDirect(): WindTurbine | null;

  applyReverseEdit(versionEdit: VersionEdit): WindTurbine;

  create(spec?: UpsertSpec): WindTurbine | null;

  static createBatch(objs: Array_Type<WindTurbine>, spec?: UpsertSpec): ObjList<WindTurbine> | null;

  static createBatchObjStream(objs: Stream<WindTurbine>, spec?: CreateBatchObjStreamSpec): ObjList<WindTurbine> | null;

  update(srcObj?: WindTurbine, spec?: UpsertSpec): WindTurbine | null;

  upsert(srcObj?: WindTurbine, spec?: UpsertSpec): WindTurbine | null;

  merge(spec?: MergeSpec): WindTurbine | null;

  touch(spec?: TouchSpec): WindTurbine | null;

  static updateBatch(objs: Array_Type<WindTurbine>, srcObjs?: Array_Type<WindTurbine>, spec?: UpsertSpec): ObjList<WindTurbine> | null;

  static upsertBatch(objs: Array_Type<WindTurbine>, srcObjs?: Array_Type<WindTurbine>, spec?: UpsertSpec): ObjList<WindTurbine> | null;

  static touchBatch(objs: Array_Type<WindTurbine>, spec?: TouchSpec): ObjList<WindTurbine> | null;

  static mergeBatch(objs: Array_Type<WindTurbine>, spec?: MergeSpec): ObjList<WindTurbine> | null;

  static mergeAll(mergeObj: WindTurbine, spec?: MergeAllSpec): number | null;

  remove(spec?: UpsertSpec): boolean;

  static removeBatch(objs: Array_Type<WindTurbine>, spec?: UpsertSpec): ObjList<WindTurbine> | null;

  static removeAll(spec?: RemoveAllSpec, confirm: boolean): number;

  static replace(objs: Array_Type<WindTurbine>, spec?: UpsertSpec): ObjList<WindTurbine> | null;

  unremove(): WindTurbine | null;

  static beforeCreate(objs: Array_Type<WindTurbine>): ObjList<WindTurbine>;

  static beforeUpdate(objs: Array_Type<WindTurbine>): ObjList<WindTurbine>;

  static beforeRemove(objs: Array_Type<WindTurbine>): ObjList<WindTurbine>;

  static afterCreate(objs: Array_Type<WindTurbine>): Array_Type<ObjError> | null;

  static afterUpdate(objs: Array_Type<WindTurbine>): Array_Type<ObjError> | null;

  static afterRemove(objs: Array_Type<WindTurbine>): Array_Type<ObjError> | null;

  upsertDirect(merge?: boolean, clearNullValues?: boolean): Obj | null;

  static beginUpsertToSecondaryDs(type: Type): SecondaryDsUpsert;

  static clearCollection(spec?: ClearCollectionSpec, confirm: boolean): void;

  static created(txn: Transaction): void;

  static updated(txn: Transaction): void;

  static removed(txn: Transaction): void;

  static evaluateOvi(spec?: EvaluateSpec): any | null;

  static refreshCalcFields(spec?: RefreshCalcFieldsSpec): RefreshCalcFieldsBatchJob | null;

  static refreshDefaultFields(spec?: RefreshDefaultFieldsSpec): RefreshDefaultFieldsBatchJob | null;

  static refreshUniqueIndexes(spec?: RefreshUniqueIndexesSpec): RefreshUniqueIndexesBatchJob | null;

  static refreshAnalytics(spec?: RefreshAnalyticsSpec): RefreshAnalyticsBatchJob | null;

  static refreshMetrics(spec?: RefreshMetricsSpec): RefreshMetricsBatchJob | null;

  static runCreatedOrUpdated(spec?: RunCreatedOrUpdatedSpec): RunCreatedOrUpdatedBatchJob | null;

  static refreshDeps(spec?: RefreshDepsSpec): void;

  static processRefresh(type: Type, jobType: Type, spec: ObjBatch): RefreshBatchJob<any, any, any> | null;

  static startImportData(spec?: StartImportDataSpec): PushStream<WindTurbine>;

  static startImportDataWithStats(spec?: StartImportDataSpec): PushStreamWithStats<WindTurbine>;

  static importData(spec: ImportDataSpec, async?: boolean): ImportDataResult | null;

  static exportData(spec: ExportDataSpec): ExportDataResult | null;

  static exportDataForRedShift(spec: RedShiftExportDataSpec): number | null;

  static forId(id: string, failIfMissing?: boolean): WindTurbine | null;

  referenceInvalid(): boolean;

  static generateNewIds(count?: number): Array_Type<string> | null;

  static generateData(spec?: GenerateDataSpec): ActionStats | null;

  static profileData(spec?: FetchSpec): GenerateDataSpec | null;

  withoutIdentity(): WindTurbine | null;

  typeOf(): EntityType | null;

  static typeOfBatch(objs: Array_Type<WindTurbine>): Array_Type<EntityType> | null;

  static getRootType(): Type | null;

  static upsertCollection(old?: Type): boolean;

  static collectionUpserted(): void;

  static collectionCleared(): void;

  static dbEcho(template?: WindTurbine, count?: number, sendBack?: boolean): number | null;

  static checkReferences(spec?: CheckReferencesSpec): CheckReferencesResult | null;

  static validatePath(path: string): ValidatePathResult | null;

  static schema(): SchemaInfo | null;

  static calcFieldDeps(fieldName: string): Array_Type<string> | null;

  invalidateTsHeader(range?: TimeRange, fields?: Array_Type<string>, autoCommit?: boolean): void;

  static invalidateTsDataPoints(tsInvalidations: Stream<TsInvalidation>, autoCommit?: boolean): void;

  static eachObjBatch(spec: BatchFetchSpec, action: λBiConsumer<Array_Type<Obj>, any | null>): string;

  static callbackLogic(objs: Array_Type<WindTurbine>, callback?: λFunction<WindTurbine | null, WindTurbine | null>): ObjList<WindTurbine>;

  static afterCallbackLogic(objs: Array_Type<WindTurbine>, callback?: λFunction<WindTurbine | null, WindTurbine | null>): Array_Type<ObjError> | null;

  static isSystemField(name: string): boolean;

  static gearOilTemperatureStats(turbinId: string): DescriptiveStatisticsResult | null;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
