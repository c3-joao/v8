// TypeScript definitions for the C3 type WindTurbineEvent

/**
 * Annotation to store the data for this type in a key-value store
 *
 * @remarks this represents a value passed to a method that expects an instance of WindTurbineEvent
 */
declare class IWindTurbineEvent {

  /**
   * Unique id that can either be manually specified or automatically generated during object creation.  Can't be
   * changed once instance is persisted.
   */
  id: string;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  versionEdits?: Array_Type<VersionEdit> | Array<IVersionEdit>;

  /**
   * Name of the Obj instance
   */
  name?: string;

  /**
   * Various system fields.
   */
  meta?: IMeta;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  version?: number;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  typeWithBindings?: IType;

  /**
   * The start time for the event
   */
  start?: DateTime | Date | string;

  /**
   * The id of the WindTurbine
   */
  turbineId?: IWindTurbine;

  /**
   * The end time for the event
   */
  end?: DateTime | Date | string;

  /**
   * The specific event code
   */
  event_code?: string;
}

/**
 * Annotation to store the data for this type in a key-value store
 *
 * @remarks this represents a made instance of WindTurbineEvent
 */
declare class WindTurbineEvent {

  /**
   * Unique id that can either be manually specified or automatically generated during object creation.  Can't be
   * changed once instance is persisted.
   */
  readonly id: string;
  withId(id: string): WindTurbineEvent;

  /**
   * Version history.  Only populated when version history is enabled.  Used for retrieving earlier versions of an Obj.
   *
   * Completely and automatically managed by the system.
   *
   * @see Ann.Db.versionHistory
   */
  readonly versionEdits?: Array_Type<VersionEdit>;
  withVersionEdits(versionEdits: Array_Type<VersionEdit> | Array<IVersionEdit> | null): WindTurbineEvent;

  /**
   * Name of the Obj instance
   */
  readonly name?: string;
  withName(name: string | null): WindTurbineEvent;

  /**
   * Various system fields.
   */
  readonly meta?: Meta;
  withMeta(meta: IMeta | null): WindTurbineEvent;

  /**
   * Version number used for optimistic concurrency.  Automatically managed by the system.
   *
   * Updating an Obj with a null or 0 value for version will cause the concurrency check to be skipped and should only
   * be done with great caution.
   */
  readonly version?: number;
  withVersion(version: number | null): WindTurbineEvent;

  /**
   * Persists concrete type with bindings for generic types where instance has parameter bindings
   */
  readonly typeWithBindings?: Type;
  withTypeWithBindings(typeWithBindings: IType | null): WindTurbineEvent;

  /**
   * The start time for the event
   */
  readonly start?: DateTime;
  withStart(start: DateTime | Date | string | null): WindTurbineEvent;

  /**
   * The id of the WindTurbine
   */
  readonly turbineId?: WindTurbine;
  withTurbineId(turbineId: IWindTurbine | null): WindTurbineEvent;

  /**
   * The end time for the event
   */
  readonly end?: DateTime;
  withEnd(end: DateTime | Date | string | null): WindTurbineEvent;

  /**
   * The specific event code
   */
  readonly event_code?: string;
  withEvent_code(event_code: string | null): WindTurbineEvent;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): WindTurbineEvent | null;

  static fromJsonString(json: string): WindTurbineEvent | null;

  static fromXmlString(xml: string): WindTurbineEvent | null;

  static deserialize(contentStr: string, contentType: string): WindTurbineEvent | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): WindTurbineEvent;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbineEvent;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): WindTurbineEvent;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbineEvent>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<WindTurbineEvent>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): WindTurbineEvent;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbineEvent;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): WindTurbineEvent;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): WindTurbineEvent;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): WindTurbineEvent;

  withField(field: FieldType, value: any, doNotConvert?: boolean): WindTurbineEvent;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): WindTurbineEvent;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): WindTurbineEvent;

  withoutField(field: string): WindTurbineEvent;

  withoutField(field: FieldType): WindTurbineEvent;

  withoutFields(fields: Array_Type<string>): WindTurbineEvent;

  withoutFieldsByType(fields: Array_Type<FieldType>): WindTurbineEvent;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): WindTurbineEvent;

  mergeObj(other: Obj): WindTurbineEvent;

  mergeObj(other: Obj, otherFieldsFilter: Type): WindTurbineEvent;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): WindTurbineEvent;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): WindTurbineEvent;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): WindTurbineEvent;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): WindTurbineEvent;

  sumObj(other: Obj, deep?: boolean): WindTurbineEvent;

  singletonArray(): Array_Type<WindTurbineEvent>;

  static array(...elements: Array_Type<any>[]): Array_Type<WindTurbineEvent> | null;

  static arrayBuilder(): ArrayBuilder<WindTurbineEvent> | null;

  singletonSet(): Set_Type<WindTurbineEvent>;

  static setBuilder(): SetBuilder<WindTurbineEvent> | null;

  static mapBuilder(): MapBuilder<string, WindTurbineEvent> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, WindTurbineEvent> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<WindTurbineEvent>;

  static builder(): ObjBuilder<WindTurbineEvent>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): WindTurbineEvent;

  static make(withDefaults?: boolean): WindTurbineEvent;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): WindTurbineEvent;

  static make(fields: any, withDefaults?: boolean): WindTurbineEvent;

  static make(s: string): WindTurbineEvent | null;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): WindTurbineEvent;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): WindTurbineEvent;

  static cachedEmptyInst(): WindTurbineEvent;

  toData(): Data | null;

  static fetch(spec?: FetchSpec): FetchResult<WindTurbineEvent>;

  static fetch(filter: Filter): FetchResult<WindTurbineEvent>;

  static fetchObjStream(spec?: FetchStreamSpec): Stream<WindTurbineEvent> | null;

  static fetchMultiLocale(spec?: MultiLocaleFetchSpec): Map_Type<string, FetchResult<WindTurbineEvent>> | null;

  static fetchCount(spec?: FetchFilterSpec): number;

  static fetchCountEstimated(spec?: FetchFilterSpec, updateStatistics?: boolean): number;

  static scan(spec: ScanSpec): ScanStats | null;

  static batchIds(spec?: BatchIdsSpec): Stream<string> | null;

  static exists(spec?: ExistsSpec): boolean;

  static exists(filter: Filter): boolean;

  static fetchOvi(spec?: FetchSpec): any | null;

  get(include?: string): WindTurbineEvent | null;

  getSpecific(include?: string): WindTurbineEvent | null;

  getMissing(spec: GetMissingSpec): WindTurbineEvent;

  getDirect(): WindTurbineEvent | null;

  applyReverseEdit(versionEdit: VersionEdit): WindTurbineEvent;

  static keyFieldType(): FieldType;

  keyFieldValue(): string | null;

  singletonMap(): Map_Type<string, WithKey>;

  toString(): string | null;

  static fromString(s: string): WindTurbineEvent | null;

  create(spec?: UpsertSpec): WindTurbineEvent | null;

  static createBatch(objs: Array_Type<WindTurbineEvent>, spec?: UpsertSpec): ObjList<WindTurbineEvent> | null;

  static createBatchObjStream(objs: Stream<WindTurbineEvent>, spec?: CreateBatchObjStreamSpec): ObjList<WindTurbineEvent> | null;

  update(srcObj?: WindTurbineEvent, spec?: UpsertSpec): WindTurbineEvent | null;

  upsert(srcObj?: WindTurbineEvent, spec?: UpsertSpec): WindTurbineEvent | null;

  merge(spec?: MergeSpec): WindTurbineEvent | null;

  touch(spec?: TouchSpec): WindTurbineEvent | null;

  static updateBatch(objs: Array_Type<WindTurbineEvent>, srcObjs?: Array_Type<WindTurbineEvent>, spec?: UpsertSpec): ObjList<WindTurbineEvent> | null;

  static upsertBatch(objs: Array_Type<WindTurbineEvent>, srcObjs?: Array_Type<WindTurbineEvent>, spec?: UpsertSpec): ObjList<WindTurbineEvent> | null;

  static touchBatch(objs: Array_Type<WindTurbineEvent>, spec?: TouchSpec): ObjList<WindTurbineEvent> | null;

  static mergeBatch(objs: Array_Type<WindTurbineEvent>, spec?: MergeSpec): ObjList<WindTurbineEvent> | null;

  static mergeAll(mergeObj: WindTurbineEvent, spec?: MergeAllSpec): number | null;

  remove(spec?: UpsertSpec): boolean;

  static removeBatch(objs: Array_Type<WindTurbineEvent>, spec?: UpsertSpec): ObjList<WindTurbineEvent> | null;

  static removeAll(spec?: RemoveAllSpec, confirm: boolean): number;

  static replace(objs: Array_Type<WindTurbineEvent>, spec?: UpsertSpec): ObjList<WindTurbineEvent> | null;

  unremove(): WindTurbineEvent | null;

  static beforeCreate(objs: Array_Type<WindTurbineEvent>): ObjList<WindTurbineEvent>;

  static beforeUpdate(objs: Array_Type<WindTurbineEvent>): ObjList<WindTurbineEvent>;

  static beforeRemove(objs: Array_Type<WindTurbineEvent>): ObjList<WindTurbineEvent>;

  static afterCreate(objs: Array_Type<WindTurbineEvent>): Array_Type<ObjError> | null;

  static afterUpdate(objs: Array_Type<WindTurbineEvent>): Array_Type<ObjError> | null;

  static afterRemove(objs: Array_Type<WindTurbineEvent>): Array_Type<ObjError> | null;

  upsertDirect(merge?: boolean, clearNullValues?: boolean): Obj | null;

  static beginUpsertToSecondaryDs(type: Type): SecondaryDsUpsert;

  static clearCollection(spec?: ClearCollectionSpec, confirm: boolean): void;

  static created(txn: Transaction): void;

  static updated(txn: Transaction): void;

  static removed(txn: Transaction): void;

  static eval(spec?: EvalSpec): Data | null;

  static evaluate(spec: EvaluateSpec): EvaluateResult | null;

  static evaluateTupleStream(spec: EvaluateSpec): Stream<CellTuple> | null;

  static evaluatePii(spec: EvaluateSpec): EvaluateResult | null;

  static tsEval(spec: TSEvalSpec): Obj | null;

  static evaluateOvi(spec?: EvaluateSpec): any | null;

  static refreshCalcFields(spec?: RefreshCalcFieldsSpec): RefreshCalcFieldsBatchJob | null;

  static refreshDefaultFields(spec?: RefreshDefaultFieldsSpec): RefreshDefaultFieldsBatchJob | null;

  static refreshUniqueIndexes(spec?: RefreshUniqueIndexesSpec): RefreshUniqueIndexesBatchJob | null;

  static refreshAnalytics(spec?: RefreshAnalyticsSpec): RefreshAnalyticsBatchJob | null;

  static refreshMetrics(spec?: RefreshMetricsSpec): RefreshMetricsBatchJob | null;

  static runCreatedOrUpdated(spec?: RunCreatedOrUpdatedSpec): RunCreatedOrUpdatedBatchJob | null;

  static refreshDeps(spec?: RefreshDepsSpec): void;

  static processRefresh(type: Type, jobType: Type, spec: ObjBatch): RefreshBatchJob<any, any, any> | null;

  static startImportData(spec?: StartImportDataSpec): PushStream<WindTurbineEvent>;

  static startImportDataWithStats(spec?: StartImportDataSpec): PushStreamWithStats<WindTurbineEvent>;

  static importData(spec: ImportDataSpec, async?: boolean): ImportDataResult | null;

  static exportData(spec: ExportDataSpec): ExportDataResult | null;

  static exportDataForRedShift(spec: RedShiftExportDataSpec): number | null;

  static forId(id: string, failIfMissing?: boolean): WindTurbineEvent | null;

  referenceInvalid(): boolean;

  static generateNewIds(count?: number): Array_Type<string> | null;

  static generateData(spec?: GenerateDataSpec): ActionStats | null;

  static profileData(spec?: FetchSpec): GenerateDataSpec | null;

  withoutIdentity(): WindTurbineEvent | null;

  typeOf(): EntityType | null;

  static typeOfBatch(objs: Array_Type<WindTurbineEvent>): Array_Type<EntityType> | null;

  static getRootType(): Type | null;

  static upsertCollection(old?: Type): boolean;

  static collectionUpserted(): void;

  static collectionCleared(): void;

  static dbEcho(template?: WindTurbineEvent, count?: number, sendBack?: boolean): number | null;

  static checkReferences(spec?: CheckReferencesSpec): CheckReferencesResult | null;

  static validatePath(path: string): ValidatePathResult | null;

  static schema(): SchemaInfo | null;

  static calcFieldDeps(fieldName: string): Array_Type<string> | null;

  invalidateTsHeader(range?: TimeRange, fields?: Array_Type<string>, autoCommit?: boolean): void;

  static invalidateTsDataPoints(tsInvalidations: Stream<TsInvalidation>, autoCommit?: boolean): void;

  static eachObjBatch(spec: BatchFetchSpec, action: λBiConsumer<Array_Type<Obj>, any | null>): string;

  static callbackLogic(objs: Array_Type<WindTurbineEvent>, callback?: λFunction<WindTurbineEvent | null, WindTurbineEvent | null>): ObjList<WindTurbineEvent>;

  static afterCallbackLogic(objs: Array_Type<WindTurbineEvent>, callback?: λFunction<WindTurbineEvent | null, WindTurbineEvent | null>): Array_Type<ObjError> | null;

  static isSystemField(name: string): boolean;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
