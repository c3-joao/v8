// TypeScript definitions for the C3 type UiSdlCustomLayoutContainerReact

/**
 * @remarks this represents a value passed to a method that expects an instance of UiSdlCustomLayoutContainerReact
 */
declare class IUiSdlCustomLayoutContainerReact {

  /**
   * The subtitle to display
   */
  subtitle?: IUiSdlDynamicValueSpec | string;

  /**
   * Various system fields.
   */
  meta?: IMeta;

  /**
   * Unique identifier for the logical object that instance of this type represents.
   */
  id?: string;

  /**
   * The name of the component. Optional field for informational purposes only.
   */
  name?: string;

  /**
   * The data settings for this component.
   *
   * @uiSdlDesignerCustomRenderer(rendererType='')
   */
  dataSpec?: IUiSdlNoData;

  /**
   * Disable if you want to avoid sending any and all requests for this component on first render.
   */
  disableDataRequestOnFirstRender?: boolean;

  /**
   * Whether the effect triggers and epics have been registered
   */
  triggersRegistered?: boolean;

  /**
   * Whether to wrap the component with a div which has a class name of its metdata id. Useful for targeting with css.
   */
  wrapWithMetadataId?: boolean;

  /**
   * The title for layout container, a {@link UiSdlLayoutContainerTitle} instance.
   */
  title?: IUiSdlLayoutContainerTitle;

  /**
   * Whether to wrap the children components in a card layout. When
   * {@link title} is defined, this is forced to `true`.
   */
  wrapped?: boolean;

  /**
   * An nested array of {@link UiSdlVariableWidthComponentRef} to be rendered in the main content.
   */
  children?: Array_Type<Array_Type<UiSdlVariableWidthComponentRef>> | Array<Array_Type<UiSdlVariableWidthComponentRef> | Array<IUiSdlVariableWidthComponentRef>>;
}

/**
 * @remarks this represents a made instance of UiSdlCustomLayoutContainerReact
 */
declare class UiSdlCustomLayoutContainerReact {

  /**
   * The subtitle to display
   */
  readonly subtitle?: UiSdlDynamicValueSpec | string;
  withSubtitle(subtitle: IUiSdlDynamicValueSpec | string | null): UiSdlCustomLayoutContainerReact;

  /**
   * Various system fields.
   */
  readonly meta?: Meta;
  withMeta(meta: IMeta | null): UiSdlCustomLayoutContainerReact;

  /**
   * Unique identifier for the logical object that instance of this type represents.
   */
  readonly id?: string;
  withId(id: string | null): UiSdlCustomLayoutContainerReact;

  /**
   * The name of the component. Optional field for informational purposes only.
   */
  readonly name?: string;
  withName(name: string | null): UiSdlCustomLayoutContainerReact;

  /**
   * The data settings for this component.
   *
   * @uiSdlDesignerCustomRenderer(rendererType='')
   */
  readonly dataSpec?: UiSdlNoData;
  withDataSpec(dataSpec: IUiSdlNoData | null): UiSdlCustomLayoutContainerReact;

  /**
   * Disable if you want to avoid sending any and all requests for this component on first render.
   */
  readonly disableDataRequestOnFirstRender?: boolean;
  withDisableDataRequestOnFirstRender(disableDataRequestOnFirstRender: boolean): UiSdlCustomLayoutContainerReact;

  /**
   * Whether the effect triggers and epics have been registered
   */
  readonly triggersRegistered?: boolean;
  withTriggersRegistered(triggersRegistered: boolean): UiSdlCustomLayoutContainerReact;

  /**
   * Whether to wrap the component with a div which has a class name of its metdata id. Useful for targeting with css.
   */
  readonly wrapWithMetadataId?: boolean;
  withWrapWithMetadataId(wrapWithMetadataId: boolean): UiSdlCustomLayoutContainerReact;

  /**
   * The title for layout container, a {@link UiSdlLayoutContainerTitle} instance.
   */
  readonly title?: UiSdlLayoutContainerTitle;
  withTitle(title: IUiSdlLayoutContainerTitle | null): UiSdlCustomLayoutContainerReact;

  /**
   * Whether to wrap the children components in a card layout. When
   * {@link title} is defined, this is forced to `true`.
   */
  readonly wrapped?: boolean;
  withWrapped(wrapped: boolean): UiSdlCustomLayoutContainerReact;

  /**
   * An nested array of {@link UiSdlVariableWidthComponentRef} to be rendered in the main content.
   */
  readonly children?: Array_Type<Array_Type<UiSdlVariableWidthComponentRef>>;
  withChildren(children: Array_Type<Array_Type<UiSdlVariableWidthComponentRef>> | Array<Array_Type<UiSdlVariableWidthComponentRef> | Array<IUiSdlVariableWidthComponentRef>> | null): UiSdlCustomLayoutContainerReact;

  toJson(): any;

  toJson(include?: string, exclude?: string): any;

  toJson(include?: Include, exclude?: Exclude): any;

  toTypedJson(omitTopLevelType?: boolean, actionRequirement?: string): any;

  toTypedJson(include?: string, exclude?: string): any;

  toTypedJson(include?: Include, exclude?: Exclude): any;

  toJsonString(): string;

  toJsonString(pretty: boolean): string;

  toTypedJsonString(): string;

  toTypedJsonString(pretty?: boolean, omitTopLevelType?: boolean): string;

  toJsString(): string;

  toJsString(withType: boolean): string;

  toXmlString(): string;

  toXmlString(withType: boolean): string;

  serialize(contentType: string): string | null;

  static fromJson(json: any): UiSdlCustomLayoutContainerReact | null;

  static fromJsonString(json: string): UiSdlCustomLayoutContainerReact | null;

  static fromXmlString(xml: string): UiSdlCustomLayoutContainerReact | null;

  static deserialize(contentStr: string, contentType: string): UiSdlCustomLayoutContainerReact | null;

  fingerprint(allIdentifiedRefFields?: boolean, trackRecursiveRefs?: boolean, traversedRefs?: SetBuilder<Obj>): number;

  retainedMemory(deep?: boolean, allMeasured?: SetBuilder<any>): number;

  type(): Type;

  replaceType(old: Type, new_: Type): UiSdlCustomLayoutContainerReact;

  super(mixin?: Type): any;

  instanceOf(typeName: string): boolean;

  instanceOf(type: Type): boolean;

  isEmptyObj(): boolean;

  isSame(other: Obj): boolean;

  fieldValue(field: string, defaultToEmpty?: boolean): T | null;

  fieldValue(field: FieldType, defaultToEmpty?: boolean): T | null;

  fieldValues(): Array_Type<FieldValue> | null;

  fieldValuesByOrdinal(skipTrailingEmpty?: boolean): Array_Type<any> | null;

  fieldValuesByFieldType(): Map_Type<FieldType, any> | null;

  fieldValuesByFieldName(): Map_Type<string, any> | null;

  fieldNames(): Array_Type<string> | null;

  at(ordinal: number): T | null;

  at(expr: string, failIfNotValid?: boolean): T | null;

  fieldValueAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): T | null;

  fieldValuesAtPath(fieldPath: string, failIfNotFound?: boolean, context?: λSupplier<string | null>): Array_Type<T> | null;

  eachFieldValue(action: λBiConsumer<FieldType, any>): void;

  eachFieldValue(spec: ValueSpec, action: λBiConsumer<FieldType, any>): void;

  eachFieldValueWhile(spec: ValueSpec, action: λBiPredicate<FieldType, any>): boolean;

  eachRef(action: λBiConsumer<FieldType, Obj>): void;

  eachRef(includeEmpty: boolean, action: λBiConsumer<FieldType, Obj>): void;

  eachRefWhile(includeEmpty: boolean, action: λBiPredicate<FieldType, Obj>): boolean;

  eachRefRecursive(includeEmpty: boolean, action: λBiConsumer<FieldPath, Obj>): void;

  eachRefRecursiveWhile(includeEmpty: boolean, action: λBiPredicate<FieldPath, Obj>): boolean;

  mapFieldValues(mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): UiSdlCustomLayoutContainerReact;

  mapFieldValues(spec: ValueSpec, mapper: λBiFunction<FieldType, any, any | null>, convertValue?: boolean): UiSdlCustomLayoutContainerReact;

  mapFieldValuesAsync(mapper: λBiFunction<FieldType, any, Promise<any> | null>, convertValue?: boolean): Promise<UiSdlCustomLayoutContainerReact>;

  mapFieldValuesAsync(spec: ValueSpec, mapper: λBiFunction<FieldType | null, any, Promise<any> | null>, convertValue?: boolean): Promise<UiSdlCustomLayoutContainerReact>;

  mapFieldValue(field?: FieldType, includeEmpty?: boolean, mapper: λFunction<any, any | null>, convertValue?: boolean): UiSdlCustomLayoutContainerReact;

  mapRefs(mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): UiSdlCustomLayoutContainerReact;

  mapRefs(includeEmpty: boolean, mapper: λBiFunction<FieldType, Obj, Obj | null>, convertValue?: boolean): UiSdlCustomLayoutContainerReact;

  foldFieldValues(folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  foldFieldValues(initial?: T, spec: ValueSpec, folder: λTriFunction<FieldType, any, T | null, T | null>): T | null;

  evalProjection(projection: string, resultType?: ValueType, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): any | null;

  evalProjection(projection: any, resultType: Type, bindings?: Map_Type<string, any>, options?: Expr.CompileOptions): Obj | null;

  validateObj(): UiSdlCustomLayoutContainerReact;

  validateObj(spec: ValidateObjSpec): ValidateObjResult;

  withField(field: string, value: any, doNotConvert?: boolean): UiSdlCustomLayoutContainerReact;

  withField(field: FieldType, value: any, doNotConvert?: boolean): UiSdlCustomLayoutContainerReact;

  withFields(fields: Map_Type<string, any>, doNotConvert?: boolean): UiSdlCustomLayoutContainerReact;

  withFieldAtPath(path: string, value: any, doNotConvert?: boolean, doNotCreateIfMissing?: boolean): UiSdlCustomLayoutContainerReact;

  withoutField(field: string): UiSdlCustomLayoutContainerReact;

  withoutField(field: FieldType): UiSdlCustomLayoutContainerReact;

  withoutFields(fields: Array_Type<string>): UiSdlCustomLayoutContainerReact;

  withoutFieldsByType(fields: Array_Type<FieldType>): UiSdlCustomLayoutContainerReact;

  withDefaults(includeEmptyRefsWithDefaults?: boolean, defaultFields?: Array_Type<string>): UiSdlCustomLayoutContainerReact;

  mergeObj(other: Obj): UiSdlCustomLayoutContainerReact;

  mergeObj(other: Obj, otherFieldsFilter: Type): UiSdlCustomLayoutContainerReact;

  mergeObj(other: Obj, deep?: boolean, merger: λQuadFunction<FieldPath | null, any | null, FieldPath | null, any | null, any | null>): UiSdlCustomLayoutContainerReact;

  mergeObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): UiSdlCustomLayoutContainerReact;

  mergeAndExpandObj(other: Obj, merger: λQuadFunction<FieldType | null, any | null, FieldType | null, any | null, any | null>): R | null;

  mergeJson(json: any): UiSdlCustomLayoutContainerReact;

  mergeChildren(deep?: boolean, objKey?: λFunction<Obj | null, any | null>, filter?: λPredicate<string>): UiSdlCustomLayoutContainerReact;

  sumObj(other: Obj, deep?: boolean): UiSdlCustomLayoutContainerReact;

  singletonArray(): Array_Type<UiSdlCustomLayoutContainerReact>;

  static array(...elements: Array_Type<any>[]): Array_Type<UiSdlCustomLayoutContainerReact> | null;

  static arrayBuilder(): ArrayBuilder<UiSdlCustomLayoutContainerReact> | null;

  singletonSet(): Set_Type<UiSdlCustomLayoutContainerReact>;

  static setBuilder(): SetBuilder<UiSdlCustomLayoutContainerReact> | null;

  static mapBuilder(): MapBuilder<string, UiSdlCustomLayoutContainerReact> | null;

  static mapBuilderOf(keyType: ValueType): MapBuilder<any, UiSdlCustomLayoutContainerReact> | null;

  static myReferenceType(): ReferenceType;

  static myMapTypeOf(keyType: ValueType): MapType;

  static myMapType(): MapType;

  static myArrayType(): ArrayType;

  static mySetType(): SetType;

  static myStreamType(): StreamType;

  toBuilder(): ObjBuilder<UiSdlCustomLayoutContainerReact>;

  static builder(): ObjBuilder<UiSdlCustomLayoutContainerReact>;

  static fromFields(fields: Map_Type<FieldType, any | any>, withDefaults?: boolean): UiSdlCustomLayoutContainerReact;

  static make(withDefaults?: boolean): UiSdlCustomLayoutContainerReact;

  static make(fields: Map_Type<string, any | any>, withDefaults?: boolean): UiSdlCustomLayoutContainerReact;

  static make(fields: any, withDefaults?: boolean): UiSdlCustomLayoutContainerReact;

  static make(s: string): UiSdlCustomLayoutContainerReact | null;

  static remake(other: Obj, failIfExtraOrInvalidFields?: boolean): UiSdlCustomLayoutContainerReact;

  remakeAs(type: Type): O;

  static beforeMake(fields: Map_Type<FieldType, any>): Map_Type<FieldType, any> | null;

  afterMake(): UiSdlCustomLayoutContainerReact;

  static cachedEmptyInst(): UiSdlCustomLayoutContainerReact;

  toData(): Data | null;

  static fetch(spec?: FetchSpec): FetchResult<UiSdlCustomLayoutContainerReact>;

  static fetch(filter: Filter): FetchResult<UiSdlCustomLayoutContainerReact>;

  static fetchObjStream(spec?: FetchStreamSpec): Stream<UiSdlCustomLayoutContainerReact> | null;

  static fetchMultiLocale(spec?: MultiLocaleFetchSpec): Map_Type<string, FetchResult<UiSdlCustomLayoutContainerReact>> | null;

  static fetchCount(spec?: FetchFilterSpec): number;

  static fetchCountEstimated(spec?: FetchFilterSpec, updateStatistics?: boolean): number;

  static scan(spec: ScanSpec): ScanStats | null;

  static batchIds(spec?: BatchIdsSpec): Stream<string> | null;

  static exists(spec?: ExistsSpec): boolean;

  static exists(filter: Filter): boolean;

  static keyFieldType(): FieldType;

  keyFieldValue(): string | null;

  singletonMap(): Map_Type<string, WithKey>;

  dependencies(): MetadataDeps<UiSdlCustomLayoutContainerReact>;

  save(subPath?: string, contentType?: string): UiSdlCustomLayoutContainerReact;

  remove(spec?: UpsertSpec): boolean;

  static removeAll(removeFilter?: string): number;

  update(srcObj?: UiSdlCustomLayoutContainerReact, spec?: UpsertSpec): UiSdlCustomLayoutContainerReact | null;

  upsert(srcObj?: UiSdlCustomLayoutContainerReact, spec?: UpsertSpec): UiSdlCustomLayoutContainerReact | null;

  static metadataFolder(): string | null;

  static hasArbitraryFolderHierarchy(): boolean;

  static isValidMetadataJson(pkg: string, filePath: string): boolean;

  toString(): string | null;

  static fromString(s: string): UiSdlCustomLayoutContainerReact | null;

  static forId(id: string, failIfMissing?: boolean): UiSdlCustomLayoutContainerReact | null;

  jsonStringify(): string | null;

  static jsonify(value?: any): string | null;

  static doDataMerge(componentId: string, dataSpecFieldName: string, dataDestinationFieldName: string, props: UiSdlCustomLayoutContainerReact, state: UiSdlReduxState): UiSdlCustomLayoutContainerReact | null;

  static renderInitialAction(id: string): UiSdlInitialRenderAction;

  static registerTriggersAction(id: string): UiSdlRegisterTriggersAction;

  triggersRegisterEffect(state: UiSdlReduxState, action: UiSdlRegisterTriggersAction): UiSdlReduxState;

  static triggerLayoutContainerAction(id?: string, actionSuffix?: string, args?: any): UiSdlLayoutContainerTriggerAction | null;

  static tsx(): string | null;

  static buildProps(type: Type, spec?: ReactComponentPropsSpec): string | null;

  constructReact(): any | null;

  toReactProps(): any | Promise<any> | null;

  static tsxPath(): string | null;

  static importedModule(): any | null;

  static render(props?: UiSdlCustomLayoutContainerReact): void;
}


interface λFunction<T, R> {
  (t: T): R
}

interface λBiFunction<T, U, R> {
  (t: T, u: U): R
}

interface λTriFunction<T, U, V, R> {
  (t: T, u: U, v: V): R
}

interface λSupplier<R> {
  (): R
}

interface λQuadFunction<T, U, V, W, R> {
  (t: T, u: U, v: V, w: W): R
}

interface λBiConsumer<T, U> {
  (t: T, u: U): void
}

interface λBiPredicate<T, U> {
  (t: T, u: U): boolean
}

interface λPredicate<T> {
  (t: T): boolean
}
