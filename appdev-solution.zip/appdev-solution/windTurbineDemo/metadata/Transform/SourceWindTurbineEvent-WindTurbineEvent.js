data = {
    name: "SourceWindTurbineEvent-WindTurbineEvent",
    source: "SourceWindTurbineEvent",
    target: "WindTurbineEvent",
    projection: {
        turbineId: {id: turbineId},
        event_code: event_code,
        start: start,
        end: end
    }
}
