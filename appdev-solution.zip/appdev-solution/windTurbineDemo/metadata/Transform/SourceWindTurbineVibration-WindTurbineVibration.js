data = {
    name: "SourceWindTurbineVibration-WindTurbineVibration",
    source: "SourceWindTurbineVibration",
    target: "WindTurbineVibration",
    projection: {
        turbineId: {id: turbineId},
        measurement_date: measurement_date,
        energyNear2xRpm: energyNear2xRpm,
        energyNear1xRpm: energyNear1xRpm
    }
}
