data = {
    name: "SourceWindTurbineMeasurement-WindTurbineMeasurement",
    source: "SourceWindTurbineMeasurement",
    target: "WindTurbineMeasurement",
    condition: exists(activePower) && exists(gearOilTemperature) && exists(generatorRotationSpeed),
    projection: {
        turbineId: {id: turbineId},
        gearOilTemperature: gearOilTemperature,
        generatorRotationSpeed: generatorRotationSpeed,
        timestamp: timestamp,
        activePower: activePower
    }
}